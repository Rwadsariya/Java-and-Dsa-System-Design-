public class Demo{
	public static void main(String[] args){
		int nums[]={5,4,7,2};
		System.out.println(nums); 
		}
}

Output: address value will get [I@d716361
==========================================================

Array Declaration:




public class Demo{
	public static void main(String[] args){
		int nums[]={5,4,7,2};
		System.out.println(nums[0]); 
		System.out.println(nums[1]); 
		System.out.println(nums[2]);
		System.out.println(nums[3]);  
		}
}


